Initial build of a backend web server with the use of Node.js aka npm

professor Ted Holmberg
written: Jamal Seder