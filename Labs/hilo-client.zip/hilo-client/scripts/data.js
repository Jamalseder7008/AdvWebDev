let gameID; //Game ID for Guesser Game
let min; //Min possible number
let max; //Max possible number
let gameover; //Manage game state
