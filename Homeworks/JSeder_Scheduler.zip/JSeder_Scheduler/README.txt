Author: Jamal Seder

Build a webpage that links to a google forms in the backend that allows for scheduling an audit with the professor

Allow for current user to have 2 tabs:
- my current schedule requests.
- make a new schedule request.

Makes use of DOM methods for retrieving information from an html document, as well as javascript modifications to those elements to navigate them to the right area of submission.

https://jamalseder7008.github.io/AuditScheduler/   <- Github page to the full project.

https://codepen.io/rachelandrew/pen/PNwaZe <- Great resource used in the development in this code. :) Thank you.