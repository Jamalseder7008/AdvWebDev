flatpickr("input[type=datetime-local]", {
        enableTime: true,
        dateFormat: "Y-m-d H:i",
        altInput: true,
        altFormat: "F J, Y (h:i K)"

    
});